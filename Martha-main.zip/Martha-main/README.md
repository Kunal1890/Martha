# Martha
An intelligent Customer Agent implemented using LangChain | OpenAI | Gradio | TTS

This project implements Langchain Document Loaders, Langchain DB Agents and use TTS to be your AI assistant. 

With a lot of room to improve, I would love to hear any feedback you might have for this project.
